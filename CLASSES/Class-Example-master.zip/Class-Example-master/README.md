# Class-Example
A simple example of creating an LED control class
